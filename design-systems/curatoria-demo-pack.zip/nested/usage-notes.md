# Usage Notes

Nested files prove that paid zip bundle downloads preserve archive structure.
