# Curatoria Demo Pack

This tiny starter bundle proves that the x402 pack download route can return
zip bytes after payment. Replace it with your own bundle before selling.
